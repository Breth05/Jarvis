package com.example.jarvis

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Reads incoming messages aloud (SMS, WhatsApp, Telegram, Signal, etc.). */
class JarvisListener : NotificationListenerService() {

    private val seen = LinkedHashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("enabled", true)) return
        if (sbn.packageName == packageName || sbn.isOngoing) return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val isMessage = n.category == Notification.CATEGORY_MESSAGE ||
            sbn.packageName in EXTRA_MESSAGING_APPS
        if (!isMessage) return

        val extras = n.extras
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (body.isBlank()) return

        // Skip duplicates (apps often re-post the same notification).
        val key = "${sbn.packageName}|$sender|$body"
        val now = System.currentTimeMillis()
        if (seen[key]?.let { now - it < 15_000 } == true) return
        seen[key] = now
        if (seen.size > 50) seen.remove(seen.keys.first())

        Speaker.say(this, "Message from $sender. ${body.take(300)}")
    }

    companion object {
        private val EXTRA_MESSAGING_APPS = setOf(
            "com.google.android.apps.messaging", "com.samsung.android.messaging",
            "com.android.mms", "com.whatsapp", "com.whatsapp.w4b",
            "org.telegram.messenger", "org.thoughtcrime.securesms"
        )
    }
}
