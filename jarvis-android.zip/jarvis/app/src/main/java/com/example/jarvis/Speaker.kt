package com.example.jarvis

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** One shared text-to-speech engine used by the notification and call listeners. */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = ArrayDeque<String>()

    fun say(context: Context, text: String) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.getDefault()
                    tts?.setPitch(0.9f)
                    ready = true
                    while (pending.isNotEmpty()) speakNow(pending.removeFirst())
                }
            }
        }
        if (ready) speakNow(text) else pending.addLast(text)
    }

    private fun speakNow(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "jarvis")
    }

    fun stop() { tts?.stop(); pending.clear() }
}
