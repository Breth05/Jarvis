package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/** Opened from the "Reply to…" notification. */
class ReplyActivity : Activity() {
    private lateinit var label: TextView
    private lateinit var orb: OrbView
    private var engine: ReplyEngine? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = this
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Ui.BG)
            setPadding(Ui.dp(ctx, 24), Ui.dp(ctx, 96), Ui.dp(ctx, 24), Ui.dp(ctx, 24))
        }
        orb = OrbView(ctx).apply { layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 220), Ui.dp(ctx, 220)) }
        label = Ui.text(ctx, "", 20f).apply {
            gravity = Gravity.CENTER
            setPadding(0, Ui.dp(ctx, 24), 0, 0)
        }
        root.addView(orb)
        root.addView(label)
        setContentView(root)

        if (PendingReply.action == null) { label.text = "Nothing to reply to."; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        else begin()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) begin()
        else label.text = "Microphone permission is needed to reply."
    }

    private fun begin() {
        engine = ReplyEngine(this, { label.text = it }, { orb.orbState = it }, { finish() })
        if (engine?.start(false) != true) label.text = "Jarvis is already replying."
    }

    override fun onDestroy() { engine?.cancel(); super.onDestroy() }
}
