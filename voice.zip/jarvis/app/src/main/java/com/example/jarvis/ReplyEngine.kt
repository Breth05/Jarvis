package com.example.jarvis

import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Voice reply flow. askFirst=true (hands-free): "Reply to X? Say yes" -> speak -> confirm -> send.
 * askFirst=false (notification tap): straight to "Speak now".
 */
class ReplyEngine(
    private val ctx: Context,
    private val status: (String) -> Unit = {},
    private val onState: (Int) -> Unit = {},
    private val finished: () -> Unit = {}
) {
    companion object { @Volatile var active = false }

    private enum class Step { ASK, DICT, CONFIRM }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var heard = ""
    private val lang: String get() = PendingReply.lang
    private val watchdog = Runnable { if (active) finish() }

    fun start(askFirst: Boolean): Boolean {
        if (active || PendingReply.action == null) return false
        active = true
        main.postDelayed(watchdog, 90_000)
        if (askFirst) say(Lang.askReply(lang, PendingReply.sender)) { listen(Step.ASK) }
        else say(Lang.replyTo(lang, PendingReply.sender)) { listen(Step.DICT) }
        return true
    }

    private fun say(text: String, next: () -> Unit) {
        status(text)
        onState(OrbView.SPEAKING)
        Speaker.sayThen(ctx, text, lang) { main.post { if (active) next() } }
    }

    private fun listen(step: Step) {
        if (!active) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            status("Speech recognition isn't available on this phone."); finish(); return
        }
        onState(OrbView.LISTENING)
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                when (step) {
                    Step.ASK -> onAsk(t)
                    Step.DICT -> onDict(t)
                    Step.CONFIRM -> onConfirm(t)
                }
            }
            override fun onError(error: Int) {
                if (step == Step.ASK) finish() else say(Lang.didntCatch(lang)) { finish() }
            }
            override fun onReadyForSpeech(p: Bundle?) {
                status(when (step) {
                    Step.ASK -> "Say yes to reply…"
                    Step.DICT -> "Listening…"
                    Step.CONFIRM -> "Say send or cancel…"
                })
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Lang.speechTag(lang))
        )
    }

    private fun onAsk(t: String) {
        if (Lang.wantsReply(t)) say(Lang.speakNow(lang)) { listen(Step.DICT) } else finish()
    }

    private fun onDict(t: String) {
        if (t.isBlank()) { finish(); return }
        heard = t
        status("\"$t\"")
        say(Lang.youSaid(lang, t)) { listen(Step.CONFIRM) }
    }

    private fun onConfirm(t: String) {
        if (Lang.isYes(t)) send() else say(Lang.cancelled(lang)) { finish() }
    }

    private fun send() {
        val a = PendingReply.action
        if (a == null) { finish(); return }
        try {
            val inputs = a.remoteInputs
            val results = Bundle().apply { putCharSequence(inputs[0].resultKey, heard) }
            val intent = Intent()
            RemoteInput.addResultsToIntent(inputs, intent, results)
            a.actionIntent.send(ctx, 0, intent)
            PendingReply.action = null
            say(Lang.sent(lang)) { finish() }
        } catch (e: Exception) {
            say(Lang.sendFail(lang)) { finish() }
        }
    }

    private fun end() {
        main.removeCallbacks(watchdog)
        rec?.destroy()
        rec = null
        active = false
    }

    private fun finish() { end(); onState(OrbView.IDLE); finished() }
    fun cancel() = end()
}
