package com.example.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Talks to the Claude API with the user's own key. */
object Claude {
    const val MODEL = "claude-haiku-5-5"
    private const val SYSTEM =
        "You are Jarvis, a calm, quick-witted voice assistant. Your reply is read aloud: " +
        "use one to three short sentences, plain speech, no markdown, no lists. " +
        "Reply in the same language the user speaks (English or Kiswahili)."

    private fun prefs(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun key(c: Context): String = prefs(c).getString("apikey", "") ?: ""
    fun hasKey(c: Context) = key(c).isNotBlank()
    fun saveKey(c: Context, k: String) = prefs(c).edit().putString("apikey", k).apply()

    /** history alternates user/assistant and ends with a user message. cb runs on a background thread. */
    fun ask(c: Context, history: List<Pair<String, String>>, cb: (Result<String>) -> Unit) {
        val appContext = c.applicationContext
        Thread {
            val result = runCatching {
                val k = key(appContext)
                if (k.isBlank()) error("nokey")
                val msgs = JSONArray()
                history.takeLast(10).forEach { (role, text) ->
                    msgs.put(JSONObject().put("role", role).put("content", text))
                }
                val body = JSONObject()
                    .put("model", MODEL).put("max_tokens", 300)
                    .put("system", SYSTEM).put("messages", msgs)
                val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("content-type", "application/json")
                    setRequestProperty("x-api-key", k)
                    setRequestProperty("anthropic-version", "2023-06-01")
                }
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (code !in 200..299) error("http$code")
                val content = JSONObject(text).getJSONArray("content")
                buildString {
                    for (i in 0 until content.length()) {
                        val b = content.getJSONObject(i)
                        if (b.optString("type") == "text") append(b.getString("text"))
                    }
                }.trim()
            }
            cb(result)
        }.start()
    }

    fun friendlyError(e: Throwable): String = when (e.message) {
        "nokey" -> "Add your API key in the Jarvis app first."
        "http401", "http403" -> "Your API key was rejected. Check it in the Jarvis app."
        "http429" -> "Too many requests. Wait a moment and try again."
        else -> "I couldn't reach the AI. Check your internet and try again."
    }
}
