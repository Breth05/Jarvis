package com.example.jarvis

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    val BG = Color.parseColor("#050D14")
    val CARD = Color.parseColor("#0B1A26")
    val ACC = Color.parseColor("#4FD1FF")
    val TXT = Color.parseColor("#D8EEF7")
    val DIM = Color.parseColor("#7F9DB0")

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun bg(c: Context, color: Int, radius: Int = 16, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(c, radius).toFloat()
            if (stroke != 0) setStroke(dp(c, 1), stroke)
        }

    fun text(c: Context, s: String, size: Float, color: Int = TXT, bold: Boolean = false) = TextView(c).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    fun button(c: Context, label: String, filled: Boolean = false, onClick: () -> Unit) = Button(c).apply {
        text = label
        setAllCaps(false)
        textSize = 15f
        setTextColor(if (filled) BG else ACC)
        background = if (filled) bg(c, ACC, 14) else bg(c, CARD, 14, ACC)
        stateListAnimator = null
        setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, 10) }
    }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = bg(c, CARD, 18)
        setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 16))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, 14) }
    }
}
