package com.example.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/** The animated Jarvis circle. Set orbState to change how it moves. */
class OrbView(context: Context) : View(context) {
    companion object { const val IDLE = 0; const val LISTENING = 1; const val THINKING = 2; const val SPEAKING = 3 }

    var orbState = IDLE
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private var t = 0f
    private val accent = Color.parseColor("#4FD1FF")
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 6000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy) * 0.95f
        val speed = when (orbState) { LISTENING -> 2; THINKING -> 5; SPEAKING -> 3; else -> 1 }
        val amp = when (orbState) { LISTENING -> 0.07f; THINKING -> 0.03f; SPEAKING -> 0.12f; else -> 0.02f }
        val spin = t * 360f * speed
        val pulse = 1f + amp * sin(t * 2f * PI.toFloat() * speed * 3f)

        // soft glow
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx, cy, r, intArrayOf(0x664FD1FF, 0x004FD1FF), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r, paint)
        paint.shader = null

        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = accent

        // outer ring
        paint.strokeWidth = r * 0.025f
        paint.alpha = 150
        canvas.drawCircle(cx, cy, r * 0.9f * pulse, paint)

        // middle ring: three arcs spinning one way
        paint.strokeWidth = r * 0.05f
        paint.alpha = 220
        var rr = r * 0.7f
        oval.set(cx - rr, cy - rr, cx + rr, cy + rr)
        for (i in 0..2) canvas.drawArc(oval, spin + i * 120f, 70f, false, paint)

        // inner ring: two arcs spinning the other way
        paint.strokeWidth = r * 0.04f
        paint.alpha = 180
        rr = r * 0.5f
        oval.set(cx - rr, cy - rr, cx + rr, cy + rr)
        for (i in 0..1) canvas.drawArc(oval, -spin * 1.5f + i * 180f, 110f, false, paint)

        // core
        paint.style = Paint.Style.FILL
        paint.alpha = 255
        canvas.drawCircle(cx, cy, r * 0.2f * pulse, paint)
    }
}
