package com.example.jarvis

import android.app.Notification

/** The most recent message that can be answered. */
object PendingReply {
    var action: Notification.Action? = null
    var sender: String = ""
    var lang: String = "en"
}
