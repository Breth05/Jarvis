package com.example.jarvis

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale

/** One shared text-to-speech engine. English / Kiswahili, adjustable speed, tone and voice. */
object Speaker {
    private class Item(val text: String, val lang: String, val cb: (() -> Unit)?)

    private var tts: TextToSpeech? = null
    private var appCtx: Context? = null
    private var ready = false
    private val pending = ArrayDeque<Item>()
    private val callbacks = HashMap<String, () -> Unit>()
    private var counter = 0

    private fun prefs(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun rate(c: Context) = prefs(c).getFloat("rate", 0.9f)
    fun pitch(c: Context) = prefs(c).getFloat("pitch", 0.8f)
    fun setRate(c: Context, v: Float) = prefs(c).edit().putFloat("rate", v).apply()
    fun setPitch(c: Context, v: Float) = prefs(c).edit().putFloat("pitch", v).apply()

    /** Start the voice engine early so voices are ready when needed. */
    fun init(context: Context) {
        if (tts != null) return
        appCtx = context.applicationContext
        tts = TextToSpeech(appCtx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { callbacks.remove(id)?.invoke() }
                    @Suppress("OVERRIDE_DEPRECATION")
                    override fun onError(id: String?) { callbacks.remove(id)?.invoke() }
                })
                ready = true
                while (pending.isNotEmpty()) pending.removeFirst().let { speakNow(it.text, it.lang, it.cb) }
            }
        }
    }

    fun say(context: Context, text: String, lang: String = "en") = sayThen(context, text, lang, null)

    fun sayThen(context: Context, text: String, lang: String = "en", onDone: (() -> Unit)? = null) {
        init(context)
        if (ready) speakNow(text, lang, onDone) else pending.addLast(Item(text, lang, onDone))
    }

    private fun speakNow(text: String, lang: String, cb: (() -> Unit)?) {
        val c = appCtx ?: return
        val t = tts ?: return
        val r = t.setLanguage(Lang.locale(lang))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
            t.language = Locale.getDefault()
        // setLanguage resets the voice, so apply the chosen voice afterwards.
        val wanted = prefs(c).getString("voice_$lang", null)
        if (wanted != null) t.voices?.firstOrNull { it.name == wanted }?.let { t.voice = it }
        t.setPitch(pitch(c))
        t.setSpeechRate(rate(c))
        val id = "j${counter++}"
        if (cb != null) callbacks[id] = cb
        t.speak(text, TextToSpeech.QUEUE_ADD, null, id)
    }

    fun voicesFor(lang: String): List<Voice> {
        val code = if (lang == "sw") "sw" else "en"
        return (tts?.voices ?: emptySet()).filter { it.locale.language == code }.sortedBy { it.name }
    }

    /** Switch to the next installed voice for this language and speak a sample. */
    fun nextVoice(context: Context, lang: String) {
        init(context)
        val list = voicesFor(lang)
        if (!ready || list.isEmpty()) {
            say(context, "No other voices found yet. Try again in a moment.", "en")
            return
        }
        val p = prefs(context)
        val cur = p.getString("voice_$lang", null)
        val next = (list.indexOfFirst { it.name == cur } + 1) % list.size
        p.edit().putString("voice_$lang", list[next].name).apply()
        val n = next + 1
        say(context,
            if (lang == "sw") "Habari, mimi ni Jarvis. Sauti $n kati ya ${list.size}."
            else "Hello, I am Jarvis. Voice $n of ${list.size}.", lang)
    }

    fun stop() { tts?.stop(); pending.clear(); callbacks.clear() }
}
