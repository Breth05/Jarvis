package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Voice chat with Claude. Tap the circle, speak, hear the answer. */
class ChatActivity : Activity() {
    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var log: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private var rec: SpeechRecognizer? = null
    private val history = mutableListOf<Pair<String, String>>()
    private var busy = false
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    private fun chatLang() = prefs.getString("chatLang", "en") ?: "en"
    private fun langLabel() = if (chatLang() == "sw") "I hear: Kiswahili" else "I hear: English"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = this
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(Ui.dp(ctx, 20), Ui.dp(ctx, 44), Ui.dp(ctx, 20), Ui.dp(ctx, 16))
        }

        val top = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Ui.text(ctx, "JARVIS", 20f, Ui.ACC, true).apply {
            letterSpacing = 0.25f
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        val langBtn = Ui.button(ctx, langLabel()) {}
        langBtn.layoutParams = LinearLayout.LayoutParams(-2, -2)
        langBtn.setOnClickListener {
            prefs.edit().putString("chatLang", if (chatLang() == "sw") "en" else "sw").apply()
            langBtn.text = langLabel()
        }
        top.addView(langBtn)
        root.addView(top)

        orb = OrbView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 170), Ui.dp(ctx, 170)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = Ui.dp(ctx, 12)
            }
            setOnClickListener { onOrbTap() }
        }
        root.addView(orb)

        status = Ui.text(ctx, "Tap the circle and speak.", 14f, Ui.DIM).apply {
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = Ui.dp(ctx, 8); bottomMargin = Ui.dp(ctx, 8)
            }
        }
        root.addView(status)

        log = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            addView(log)
        }
        root.addView(scroll)

        val bottom = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(ctx).apply {
            hint = "Or type a message"
            setHintTextColor(Ui.DIM); setTextColor(Ui.TXT)
            inputType = InputType.TYPE_CLASS_TEXT
            background = Ui.bg(ctx, Ui.CARD, 14, Ui.DIM)
            setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 12), Ui.dp(ctx, 14), Ui.dp(ctx, 12))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val send = Ui.button(ctx, "Send", true) {
            val q = input.text.toString(); input.setText(""); ask(q)
        }
        send.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { leftMargin = Ui.dp(ctx, 8) }
        bottom.addView(input)
        bottom.addView(send)
        root.addView(bottom)
        setContentView(root)

        bubble("Good to see you. Tap the circle and ask me anything.", false)
        if (!Claude.hasKey(this))
            bubble("To answer questions I need your API key. Add it on the Jarvis home screen.", false)
    }

    private fun onOrbTap() {
        when (orb.orbState) {
            OrbView.SPEAKING -> { Speaker.stop(); setIdle() }
            OrbView.LISTENING -> rec?.stopListening()
            OrbView.IDLE -> listen()
            else -> {}
        }
    }

    private fun setIdle() { orb.orbState = OrbView.IDLE; status.text = "Tap the circle and speak." }

    private fun listen() {
        if (busy) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 3); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition isn't available on this phone."; return
        }
        Speaker.stop()
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (t.isBlank()) { setIdle(); status.text = "I didn't catch that. Tap the circle to try again." } else ask(t)
            }
            override fun onError(error: Int) { setIdle(); status.text = "I didn't catch that. Tap the circle to try again." }
            override fun onReadyForSpeech(p: Bundle?) { status.text = "Listening…" }
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    ?.takeIf { it.isNotBlank() }?.let { status.text = it }
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        orb.orbState = OrbView.LISTENING
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Lang.speechTag(chatLang()))
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        )
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) listen()
        else status.text = "Microphone permission is needed to talk."
    }

    private fun ask(q: String) {
        val text = q.trim()
        if (text.isEmpty() || busy) return
        busy = true
        bubble(text, true)
        history.add("user" to text)
        orb.orbState = OrbView.THINKING
        status.text = "Thinking…"
        Claude.ask(this, history) { result ->
            runOnUiThread {
                busy = false
                result.onSuccess { answer ->
                    val a = answer.ifBlank { "I have nothing to add." }
                    history.add("assistant" to a)
                    bubble(a, false)
                    val l = Lang.detect(a)
                    orb.orbState = OrbView.SPEAKING
                    status.text = "Speaking… tap the circle to stop."
                    Speaker.sayThen(this, a, l) { runOnUiThread { setIdle() } }
                }
                result.onFailure { e ->
                    history.removeAt(history.size - 1)
                    setIdle()
                    bubble(Claude.friendlyError(e), false)
                }
            }
        }
    }

    private fun bubble(text: String, mine: Boolean) {
        val ctx = this
        val tv = Ui.text(ctx, text, 15f).apply {
            maxWidth = Ui.dp(ctx, 300)
            background = Ui.bg(ctx, if (mine) Ui.BG else Ui.CARD, 14, if (mine) Ui.ACC else 0)
            setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 10), Ui.dp(ctx, 14), Ui.dp(ctx, 10))
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply {
                gravity = if (mine) Gravity.END else Gravity.START
                topMargin = Ui.dp(ctx, 8)
            }
        }
        log.addView(tv)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onDestroy() { rec?.destroy(); Speaker.stop(); super.onDestroy() }
}
