package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Keeps the microphone available so Jarvis can ask "Reply?" and listen without a tap. */
class HandsFreeService : Service() {
    private var engine: ReplyEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis_service", "Jarvis hands-free", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "jarvis_service")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis hands-free is on")
            .setContentText("I'll ask if you want to reply to new messages")
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(7, n)
        instance = this
    }

    fun beginReply() {
        if (ReplyEngine.active) return
        engine = ReplyEngine(this)
        engine?.start(true)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        engine?.cancel()
        instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile var instance: HandsFreeService? = null
        val running: Boolean get() = instance != null
    }
}
