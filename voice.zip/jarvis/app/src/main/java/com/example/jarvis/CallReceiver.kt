package com.example.jarvis

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.TelephonyManager

/** Announces who is calling when the phone rings. */
class CallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (!context.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getBoolean("enabled", true)) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        if (state == TelephonyManager.EXTRA_STATE_IDLE || state == TelephonyManager.EXTRA_STATE_OFFHOOK) {
            Speaker.stop(); lastNumber = null; return
        }
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return

        // Android sends one broadcast without the number and one with it; wait for the latter.
        @Suppress("DEPRECATION")
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: return
        if (number == lastNumber) return
        lastNumber = number

        val lang = Lang.pick(context, "")
        Speaker.say(context, Lang.incomingCall(lang, nameFor(context, number)), lang)
    }

    private fun nameFor(context: Context, number: String): String {
        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return number.toList().joinToString(" ")
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        context.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) return it.getString(0) }
        return number.toList().joinToString(" ")
    }

    companion object { private var lastNumber: String? = null }
}
