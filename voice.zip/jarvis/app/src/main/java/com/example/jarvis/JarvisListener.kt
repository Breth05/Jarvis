package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Reads incoming messages aloud (SMS, WhatsApp, Telegram, Signal, etc.). */
class JarvisListener : NotificationListenerService() {

    private val seen = LinkedHashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("enabled", true)) return
        if (sbn.packageName == packageName || sbn.isOngoing) return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val isMessage = n.category == Notification.CATEGORY_MESSAGE ||
            sbn.packageName in EXTRA_MESSAGING_APPS
        if (!isMessage) return

        val extras = n.extras
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (body.isBlank()) return

        // Skip duplicates (apps often re-post the same notification).
        val key = "${sbn.packageName}|$sender|$body"
        val now = System.currentTimeMillis()
        if (seen[key]?.let { now - it < 15_000 } == true) return
        seen[key] = now
        if (seen.size > 50) seen.remove(seen.keys.first())

        val lang = Lang.pick(this, body)
        val reply = n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
        val canReply = reply != null && !ReplyEngine.active
        val handsFree = canReply && HandsFreeService.running
        if (canReply) {
            PendingReply.action = reply
            PendingReply.sender = sender
            PendingReply.lang = lang
        }

        Speaker.sayThen(this, Lang.messageFrom(lang, sender, body.take(300)), lang) {
            if (handsFree) Handler(Looper.getMainLooper()).post { HandsFreeService.instance?.beginReply() }
        }
        if (canReply && !handsFree) postReplyPrompt(sender)
    }

    private fun postReplyPrompt(sender: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis_reply", "Jarvis replies", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, ReplyActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val note = Notification.Builder(this, "jarvis_reply")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Reply to $sender")
            .setContentText("Tap to reply by voice")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(42, note)
    }

    companion object {
        private val EXTRA_MESSAGING_APPS = setOf(
            "com.google.android.apps.messaging", "com.samsung.android.messaging",
            "com.android.mms", "com.whatsapp", "com.whatsapp.w4b",
            "org.telegram.messenger", "org.thoughtcrime.securesms"
        )
    }
}
