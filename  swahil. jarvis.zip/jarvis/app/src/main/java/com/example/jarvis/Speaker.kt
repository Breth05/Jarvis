package com.example.jarvis

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** One shared text-to-speech engine. Speaks English or Kiswahili; sayThen() runs a callback when done. */
object Speaker {
    private class Item(val text: String, val lang: String, val cb: (() -> Unit)?)

    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = ArrayDeque<Item>()
    private val callbacks = HashMap<String, () -> Unit>()
    private var counter = 0

    fun say(context: Context, text: String, lang: String = "en") = sayThen(context, text, lang, null)

    fun sayThen(context: Context, text: String, lang: String = "en", onDone: (() -> Unit)? = null) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.setPitch(0.9f)
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) { callbacks.remove(id)?.invoke() }
                        @Suppress("OVERRIDE_DEPRECATION")
                        override fun onError(id: String?) { callbacks.remove(id)?.invoke() }
                    })
                    ready = true
                    while (pending.isNotEmpty()) pending.removeFirst().let { speakNow(it.text, it.lang, it.cb) }
                }
            }
        }
        if (ready) speakNow(text, lang, onDone) else pending.addLast(Item(text, lang, onDone))
    }

    private fun speakNow(text: String, lang: String, cb: (() -> Unit)?) {
        val r = tts?.setLanguage(Lang.locale(lang))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
            tts?.language = Locale.getDefault()
        val id = "j${counter++}"
        if (cb != null) callbacks[id] = cb
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id)
    }

    fun stop() { tts?.stop(); pending.clear(); callbacks.clear() }
}
