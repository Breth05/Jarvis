package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.app.RemoteInput
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.TextView

/** Voice reply: hear what you say, repeat it back, send on "send". */
class ReplyActivity : Activity() {

    private lateinit var label: TextView
    private var recognizer: SpeechRecognizer? = null
    private var heard = ""
    private val lang: String get() = PendingReply.lang

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        label = TextView(this).apply {
            textSize = 22f; setTextColor(Color.WHITE)
            setPadding(48, 160, 48, 48); setBackgroundColor(Color.parseColor("#050D14"))
        }
        setContentView(label)
        if (PendingReply.action == null) { label.text = "Nothing to reply to."; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        else begin()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) begin()
        else label.text = "Microphone permission is needed to reply."
    }

    private fun begin() {
        label.text = "Reply to ${PendingReply.sender}…"
        Speaker.sayThen(this, Lang.replyTo(lang, PendingReply.sender), lang) {
            runOnUiThread { listen(false) }
        }
    }

    private fun listen(confirming: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            label.text = "Speech recognition isn't available on this phone."; return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (confirming) handleConfirm(t) else handleReply(t)
                }
                override fun onError(error: Int) {
                    label.text = "I didn't catch that. Tap the notification to try again."
                    Speaker.sayThen(this@ReplyActivity, Lang.didntCatch(lang), lang) { runOnUiThread { finish() } }
                }
                override fun onReadyForSpeech(p: Bundle?) { label.text = if (confirming) "Say send or cancel…" else "Listening…" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Lang.speechTag(lang)))
        }
    }

    private fun handleReply(text: String) {
        if (text.isBlank()) { label.text = "Nothing heard."; finish(); return }
        heard = text
        label.text = "\"$text\"\n\nSay send or cancel."
        Speaker.sayThen(this, Lang.youSaid(lang, text), lang) { runOnUiThread { listen(true) } }
    }

    private fun handleConfirm(text: String) {
        if (Lang.isYes(text)) send()
        else {
            label.text = "Cancelled."
            Speaker.sayThen(this, Lang.cancelled(lang), lang) { runOnUiThread { finish() } }
        }
    }

    private fun send() {
        val a = PendingReply.action ?: return
        try {
            val inputs = a.remoteInputs
            val results = Bundle().apply { putCharSequence(inputs[0].resultKey, heard) }
            val intent = Intent()
            RemoteInput.addResultsToIntent(inputs, intent, results)
            a.actionIntent.send(this, 0, intent)
            PendingReply.action = null
            label.text = "Sent."
            Speaker.sayThen(this, Lang.sent(lang), lang) { runOnUiThread { finish() } }
        } catch (e: Exception) {
            label.text = "Couldn't send. The message notification may have been cleared."
            Speaker.sayThen(this, Lang.sendFail(lang), lang) { runOnUiThread { finish() } }
        }
    }

    override fun onDestroy() { recognizer?.destroy(); super.onDestroy() }
}
