package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 120, 48, 48)
            setBackgroundColor(Color.parseColor("#050D14"))
        }
        fun text(s: String, size: Float, color: String) = TextView(this).apply {
            text = s; textSize = size; setTextColor(Color.parseColor(color)); setPadding(0, 0, 0, 32)
        }
        root.addView(text("JARVIS", 28f, "#4FD1FF"))
        root.addView(text("Reads your incoming texts and announces callers out loud.", 16f, "#D8EEF7"))

        root.addView(Switch(this).apply {
            text = "Jarvis on"; setTextColor(Color.parseColor("#D8EEF7"))
            isChecked = prefs.getBoolean("enabled", true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("enabled", on).apply() }
        })
        root.addView(Button(this).apply {
            text = "1. Allow phone, contacts, mic & notifications"
            setOnClickListener {
                requestPermissions(arrayOf(
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        })
        root.addView(Button(this).apply {
            text = "2. Allow notification access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Test voice"
            setOnClickListener { Speaker.say(this@MainActivity, "Message from Alex. Are we still on for tonight?") }
        })
        val langBtn = Button(this)
        fun langLabel() = when (Lang.mode(this)) {
            "sw" -> "Language: Kiswahili"
            "en" -> "Language: English"
            else -> "Language: Auto (English / Kiswahili)"
        }
        langBtn.text = langLabel()
        langBtn.setOnClickListener {
            val next = when (Lang.mode(this)) { "auto" -> "en"; "en" -> "sw"; else -> "auto" }
            Lang.setMode(this, next)
            langBtn.text = langLabel()
        }
        root.addView(langBtn)
        root.addView(Button(this).apply {
            text = "Test Kiswahili voice"
            setOnClickListener {
                Speaker.say(this@MainActivity, "Habari! Ujumbe kutoka kwa Juma. Tuonane kesho.", "sw")
            }
        })
        setContentView(root)
    }
}
