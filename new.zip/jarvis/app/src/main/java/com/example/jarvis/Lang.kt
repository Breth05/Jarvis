package com.example.jarvis

import android.content.Context
import java.util.Locale

/** English / Kiswahili helpers: detection, phrases, and the language setting. */
object Lang {
    private val STRONG = setOf(
        "habari","asante","karibu","pole","mambo","sawa","poa","tafadhali","sasa","kesho","leo","jana",
        "wapi","nini","gani","hapana","ndiyo","ndio","nakupenda","shikamoo","vipi","nimefika","nipo","upo",
        "uko","mimi","wewe","yako","yangu","lakini","kwa","sana","basi","bado","tutaonana","mchana",
        "asubuhi","usiku","rafiki","pesa","kazi","nyumbani","nipigie","pia","hamna","salama","nzuri",
        "mzuri","vizuri","ndugu","naomba","nimepokea","tuma","jibu","mwalimu","chuo","mtihani")
    private val WEAK = setOf("ni","na","wa","ya","za","la","tu","hapa","huko","kama","yote","wote")

    fun mode(c: Context): String =
        c.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("lang", "auto") ?: "auto"

    fun setMode(c: Context, m: String) =
        c.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putString("lang", m).apply()

    /** "sw" or "en" for this text, honoring the user's setting. */
    fun pick(c: Context, text: String): String { val m = mode(c); return if (m == "auto") detect(text) else m }

    fun detect(text: String): String {
        var score = 0
        for (m in Regex("[a-zA-Z']+").findAll(text.lowercase())) {
            val w = m.value
            if (w in STRONG) score += 2 else if (w in WEAK) score += 1
        }
        return if (score >= 2) "sw" else "en"
    }

    fun locale(l: String): Locale = if (l == "sw") Locale("sw") else Locale.getDefault()
    fun speechTag(l: String) = if (l == "sw") "sw-TZ" else "en-US"

    fun messageFrom(l: String, who: String, body: String) =
        if (l == "sw") "Ujumbe kutoka kwa $who. $body" else "Message from $who. $body"
    fun incomingCall(l: String, who: String) =
        if (l == "sw") "Simu inaingia kutoka kwa $who" else "Incoming call from $who"
    fun replyTo(l: String, who: String) =
        if (l == "sw") "Jibu $who. Sema sasa." else "Reply to $who. Speak now."
    fun youSaid(l: String, t: String) =
        if (l == "sw") "Umesema: $t. Sema tuma, au ghairi." else "You said: $t. Say send, or cancel."
    fun sent(l: String) = if (l == "sw") "Imetumwa." else "Sent."
    fun cancelled(l: String) = if (l == "sw") "Imeghairiwa." else "Cancelled."
    fun didntCatch(l: String) = if (l == "sw") "Sikusikia vizuri." else "I didn't catch that."
    fun sendFail(l: String) = if (l == "sw") "Samahani, imeshindikana kutuma." else "Sorry, I couldn't send that."
    fun isYes(text: String) =
        Regex("[a-zA-Z]+").findAll(text.lowercase()).any { it.value in setOf("send","yes","tuma","ndiyo","ndio","sawa") }

    fun askReply(l: String, who: String) =
        if (l == "sw") "Unataka kujibu $who? Sema ndiyo." else "Reply to $who? Say yes."
    fun speakNow(l: String) = if (l == "sw") "Sema sasa." else "Speak now."
    fun wantsReply(text: String) =
        Regex("[a-zA-Z]+").findAll(text.lowercase()).any {
            it.value in setOf("reply","yes","yeah","jibu","ndiyo","ndio","sawa","ok","okay")
        }
}
