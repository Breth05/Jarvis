package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var hands: Switch
    private var syncing = false

    private fun toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = label
        textSize = 15f
        setTextColor(Ui.TXT)
        isChecked = checked
        setPadding(0, Ui.dp(this@MainActivity, 12), 0, Ui.dp(this@MainActivity, 4))
        setOnCheckedChangeListener { _, on -> if (!syncing) onChange(on) }
    }

    private fun langLabel() = when (Lang.mode(this)) {
        "sw" -> "Language: Kiswahili"
        "en" -> "Language: English"
        else -> "Language: Auto (English / Kiswahili)"
    }

    private fun setHandsFree(on: Boolean) {
        if (on) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 2)
                Toast.makeText(this, "Allow the microphone, then switch this on again.", Toast.LENGTH_LONG).show()
                syncing = true; hands.isChecked = false; syncing = false
                return
            }
            startForegroundService(Intent(this, HandsFreeService::class.java))
        } else {
            stopService(Intent(this, HandsFreeService::class.java))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val ctx = this
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(Ui.dp(ctx, 20), Ui.dp(ctx, 56), Ui.dp(ctx, 20), Ui.dp(ctx, 40))
        }
        col.addView(Ui.text(ctx, "JARVIS", 26f, Ui.ACC, true).apply { letterSpacing = 0.3f })
        col.addView(Ui.text(ctx, "Your voice assistant", 14f, Ui.DIM))
        val orb = OrbView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 200), Ui.dp(ctx, 200)).apply { topMargin = Ui.dp(ctx, 24) }
            setOnClickListener { startActivity(Intent(ctx, ChatActivity::class.java)) }
        }
        col.addView(orb)
        col.addView(Ui.text(ctx, "Tap the circle to talk to Jarvis", 13f, Ui.DIM))

        // Messages & calls
        val c1 = Ui.card(ctx)
        c1.addView(Ui.text(ctx, "Messages & calls", 16f, Ui.TXT, true))
        c1.addView(toggle("Read texts and announce callers", prefs.getBoolean("enabled", true)) {
            prefs.edit().putBoolean("enabled", it).apply()
        })
        hands = toggle("Hands-free reply (Jarvis asks, you answer)", HandsFreeService.running) { setHandsFree(it) }
        c1.addView(hands)
        c1.addView(Ui.button(ctx, "1. Allow permissions") {
            requestPermissions(arrayOf(
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS), 1)
        })
        c1.addView(Ui.button(ctx, "2. Allow notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(c1)

        // Voice & language
        val c2 = Ui.card(ctx)
        c2.addView(Ui.text(ctx, "Voice & language", 16f, Ui.TXT, true))
        val langBtn = Ui.button(ctx, langLabel()) {}
        langBtn.setOnClickListener {
            val next = when (Lang.mode(this)) { "auto" -> "en"; "en" -> "sw"; else -> "auto" }
            Lang.setMode(this, next)
            langBtn.text = langLabel()
        }
        c2.addView(langBtn)
        c2.addView(Ui.button(ctx, "Test English voice") {
            Speaker.say(ctx, "Message from Alex. Are we still on for tonight?")
        })
        c2.addView(Ui.button(ctx, "Test Kiswahili voice") {
            Speaker.say(ctx, "Habari! Ujumbe kutoka kwa Juma. Tuonane kesho.", "sw")
        })
        col.addView(c2)

        // AI chat key
        val c3 = Ui.card(ctx)
        c3.addView(Ui.text(ctx, "AI chat", 16f, Ui.TXT, true))
        c3.addView(Ui.text(ctx,
            "Chat uses Claude. It needs internet and your own API key from console.anthropic.com. Anthropic bills the usage.",
            12f, Ui.DIM).apply { setPadding(0, Ui.dp(ctx, 6), 0, 0) })
        val keyBox = EditText(ctx).apply {
            hint = if (Claude.hasKey(ctx)) "Key saved. Paste a new one to replace." else "Paste your API key"
            setHintTextColor(Ui.DIM); setTextColor(Ui.TXT)
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            background = Ui.bg(ctx, Ui.BG, 12, Ui.DIM)
            setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 12), Ui.dp(ctx, 14), Ui.dp(ctx, 12))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(ctx, 12) }
        }
        c3.addView(keyBox)
        c3.addView(Ui.button(ctx, "Save key", true) {
            val k = keyBox.text.toString().trim()
            if (k.isNotEmpty()) {
                Claude.saveKey(ctx, k)
                keyBox.setText("")
                keyBox.hint = "Key saved. Paste a new one to replace."
                Toast.makeText(ctx, "Key saved", Toast.LENGTH_SHORT).show()
            }
        })
        col.addView(c3)

        setContentView(ScrollView(ctx).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        syncing = true
        hands.isChecked = HandsFreeService.running
        syncing = false
    }
}
